/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica2;
import java.util.Scanner;
/**
 *
 * @author Ruben Ramirez
 */
public class Practica2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese la marca: ");
        String marca = sc.nextLine();

        System.out.print("Ingrese el modelo: ");
        String modelo = sc.nextLine();

        System.out.print("Ingrese las placas: ");
        String placas = sc.nextLine();

        System.out.print("Ingrese la cantidad de gasolina: ");
        double gasolina = sc.nextDouble();

        automovil auto = new automovil(marca, modelo, placas, gasolina);

        auto.mostrarDatos();
        auto.encenderMotor();
        auto.acelerar();
        auto.frenar();

        System.out.println("Vehiculo apagado");
    }
}
    
