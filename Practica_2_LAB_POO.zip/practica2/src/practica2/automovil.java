/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2;

/**
 *
 * @author Ruben Ramirez
 */
public class automovil{

    String marca;
    String modelo;
    String placas;
    double gasolina;
    boolean motorEncendido;

    public automovil(String marca, String modelo, String placas, double gasolina){
        this.marca = marca;
        this.modelo = modelo;
        this.placas = placas;
        this.gasolina = gasolina;
        this.motorEncendido = false;
    }

    public void encenderMotor(){
        if(gasolina>0){
            motorEncendido=true;
            System.out.println("Motor encendido");
        }else{
            System.out.println("No hay gasolina");
        }
    }

    public void acelerar(){
        if(motorEncendido){
            System.out.println("ACELERANDO");
            System.out.println("Vehiculo avanzando");
            gasolina-=1;
        }else{
            System.out.println("El motor esta apagado");
        }
    }

    public void frenar(){
        System.out.println("FRENANDO");
    }

    public void mostrarDatos(){
        System.out.println(
            "El automovil " + marca + ", " + modelo + ", " + placas + " tiene GAS: " + gasolina);
    }
}

