/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

/**
 *
 * @author Ruben Ramirez
 */
public class Autobus extends TransporteTerrestre {

    private String tipoServicio;

    public Autobus(String marca, int capacidad, String tipoServicio) {
        super(marca, capacidad);
        this.tipoServicio = tipoServicio;
    }

    public void abrirPuertas() {
        System.out.println("El autobus esta abriendo puertas");
    }
}
