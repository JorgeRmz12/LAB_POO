/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

/**
 *
 * @author Ruben Ramirez
 */
public class Avion extends TransporteAereo {

    private int alturaMaxima;

    public Avion(String marca, int capacidad, int alturaMaxima) {
        super(marca, capacidad);
        this.alturaMaxima = alturaMaxima;
    }

    public void volar() {
        System.out.println("Avion Volando");
    }
}