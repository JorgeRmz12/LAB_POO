/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica4;

/**
 *
 * @author Ruben Ramirez
 */
public class Practica4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        TransporteAereo t1 = new TransporteAereo("Boing", 365);
        t1.mostrarDatos();
        t1.avanzar();

        TransporteTerrestre t2 = new TransporteTerrestre("Dina", 67);
        t2.mostrarDatos();
        t2.avanzar();

        Avion a1 = new Avion("Aeromexico", 95, 10000);
        a1.mostrarDatos();
        a1.avanzar();

        Avion a2 = new Avion("Mexicana", 90, 9000);
        a2.mostrarDatos();
        a2.avanzar();
        a2.volar();
    }
    
}
