/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;

public class ProcesadorTareas implements Runnable {

    private Tarea tarea;

    public ProcesadorTareas(Tarea tarea) {
        this.tarea = tarea;
    }

    @Override
    public void run() {

        System.out.println("Procesando tarea: " + tarea.getNombre());

        try {
            Thread.sleep(2000); // simula proceso
        } catch (InterruptedException e) {
            System.out.println("Error en hilo");
        }

        tarea.setEstado("Completada");

        System.out.println("Tarea finalizada: " + tarea.getNombre());
    }
}