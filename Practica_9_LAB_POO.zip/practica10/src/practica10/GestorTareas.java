/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;
import java.io.*;
import java.util.*;

public class GestorTareas {
    private ArrayList<Tarea> lista;
    private HashMap<Integer, Tarea> mapa;
    private HashSet<String> set;
    private LinkedList<Tarea> cola;

    private File archivo;

    public GestorTareas() {
        lista = new ArrayList<>();
        mapa = new HashMap<>();
        set = new HashSet<>();
        cola = new LinkedList<>();
        archivo = new File("tareas.txt");
    }

    public void agregarTarea(Tarea t) {

        if (set.contains(t.getNombre())) {
            System.out.println("Tarea duplicada: " + t.getNombre());
            return;
        }

        lista.add(t);
        mapa.put(t.getId(), t);
        set.add(t.getNombre());
        cola.add(t);

        System.out.println("Tarea agregada: " + t.getNombre());
    }

    public void guardarArchivo() {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            for (Tarea t : lista) {
                bw.write(t.toFileString());
                bw.newLine();
            }

            System.out.println("Tareas guardadas en archivo");

        } catch (IOException e) {
            System.out.println("Error al guardar");
        }
    }

    public void leerArchivo() {

        lista.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split(",");

                Tarea t = new Tarea(
                        Integer.parseInt(datos[0]),
                        datos[1],
                        datos[2]
                );

                lista.add(t);
            }

            System.out.println("Tareas cargadas desde archivo");

        } catch (IOException e) {
            System.out.println("Error al leer archivo");
        }
    }

    public void mostrarTareas() {
        for (Tarea t : lista) {
            System.out.println(t);
        }
    }

    public LinkedList<Tarea> getCola() {
        return cola;
    }
}
