/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica10;

public class Tarea {
    private int id;
    private String nombre;
    private String estado;

    public Tarea(int id, String nombre, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.estado = estado;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getEstado() { return estado; }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String toFileString() {
        return id + "," + nombre + "," + estado;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Nombre: " + nombre + " | Estado: " + estado;
    }
}
