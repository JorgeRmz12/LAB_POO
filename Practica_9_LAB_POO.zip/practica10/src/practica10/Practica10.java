/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica10;

public class Practica10 {

    public static void main(String[] args) {
        GestorTareas gestor = new GestorTareas();

        // Crear tareas
        gestor.agregarTarea(new Tarea(1, "Estudiar Java", "Pendiente"));
        gestor.agregarTarea(new Tarea(2, "Hacer tarea", "Pendiente"));
        gestor.agregarTarea(new Tarea(3, "Leer apuntes", "Pendiente"));

        // Guardar en archivo
        gestor.guardarArchivo();

        System.out.println("\n--- Leyendo archivo ---");
        gestor.leerArchivo();
        gestor.mostrarTareas();

        System.out.println("\n--- Procesando tareas con Threads ---");

        // Procesar tareas con hilos
        for (Tarea t : gestor.getCola()) {

            Thread hilo = new Thread(new ProcesadorTareas(t));
            hilo.start();
        }
    }
    
}
