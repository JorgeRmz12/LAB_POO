/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica8;


public class Practica8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GestorLibros gestor = new GestorLibros();

        gestor.crearCarpetaYArchivo();

        // Agregar libros
        gestor.agregarLibro(new Libro("L001", "Java Basico", "Juan Perez", 2022));
        gestor.agregarLibro(new Libro("L002", "POO en Java", "Maria Lopez", 2023));
        gestor.agregarLibro(new Libro("L003", "Estructuras de Datos", "Carlos Ruiz", 2021));

        // Guardar en archivo
        gestor.guardarLibros();

        System.out.println("\n--- Leyendo archivo ---");

        // Leer archivo
        gestor.cargarLibros();

        // Mostrar en consola
        gestor.mostrarLibros();
    }
    
}