/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica8;

public class Libro {
    private String codigo;
    private String titulo;
    private String autor;
    private int anio;

    public Libro() {}

    public Libro(String codigo, String titulo, String autor, int anio) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.autor = autor;
        this.anio = anio;
    }

    // Getters
    public String getCodigo() { return codigo; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public int getAnio() { return anio; }

    // Setters
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public void setAutor(String autor) { this.autor = autor; }
    public void setAnio(int anio) { this.anio = anio; }

    // Formato para archivo
    public String toFileString() {
        return codigo + "," + titulo + "," + autor + "," + anio;
    }

    @Override
    public String toString() {
        return "Codigo: " + codigo +
               " | Titulo: " + titulo +
               " | Autor: " + autor +
               " | Anio: " + anio;
    }
}
