/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica8;
import java.io.*;
import java.util.ArrayList;

public class GestorLibros {
    private ArrayList<Libro> libros;
    private File carpeta;
    private File archivo;

    public GestorLibros() {
        libros = new ArrayList<>();
        carpeta = new File("biblioteca");
        archivo = new File(carpeta, "libros.txt");
    }

    // Crear carpeta y archivo
    public void crearCarpetaYArchivo() {

        try {
            if (!carpeta.exists()) {
                carpeta.mkdir();
                System.out.println("Carpeta creada");
            }

            if (!archivo.exists()) {
                archivo.createNewFile();
                System.out.println("Archivo creado");
            }

        } catch (IOException e) {
            System.out.println("Error al crear archivo: " + e.getMessage());
        }
    }

    // Agregar libro
    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    // Guardar libros
    public void guardarLibros() {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {

            for (Libro l : libros) {
                bw.write(l.toFileString());
                bw.newLine();
            }

            System.out.println("Libros guardados correctamente");

        } catch (IOException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }

    // Cargar libros
    public void cargarLibros() {

        libros.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {

            String linea;

            while ((linea = br.readLine()) != null) {

                String[] datos = linea.split(",");

                Libro libro = new Libro(
                        datos[0],
                        datos[1],
                        datos[2],
                        Integer.parseInt(datos[3])
                );

                libros.add(libro);
            }

            System.out.println("Libros cargados correctamente");

        } catch (IOException e) {
            System.out.println("Error al leer: " + e.getMessage());
        }
    }

    // Mostrar libros
    public void mostrarLibros() {
        for (Libro l : libros) {
            System.out.println(l);
        }
    }
}