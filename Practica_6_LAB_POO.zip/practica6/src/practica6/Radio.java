/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

/**
 *
 * @author Ruben Ramirez
 */
public class Radio extends Dispositivo implements IComElectronicos {

    public Radio(String marca) {
        super(marca);
    }

    @Override
    public void encender() {
        System.out.println("Radio marca " + marca + " encendida");
    }

    @Override
    public void apagar() {
        System.out.println("Radio apagada");
    }

    @Override
    public void subirVolumen(int nivel) {
        System.out.println("Radio subio el volumen en " + nivel);
    }

    public void cambiarFrecuencia(double frecuencia) {
        System.out.println("Sintonizando frecuencia: " + frecuencia);
    }
}
