/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package practica6;

/**
 *
 * @author Ruben Ramirez
 */
public interface ICalculosMatematicos {
    double sumar(double a, double b);
    double restar(double a, double b);
}
