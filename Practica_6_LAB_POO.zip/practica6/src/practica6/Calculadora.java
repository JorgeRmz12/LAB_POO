/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

/**
 *
 * @author Ruben Ramirez
 */
public class Calculadora implements ICalculosMatematicos {

    @Override
    public double sumar(double a, double b) {
        return a + b;
    }

    @Override
    public double restar(double a, double b) {
        return a - b;
    }

    // SOBRECARGA (polimorfismo)
    public int sumar(int a, int b) {
        return a + b;
    }
}
