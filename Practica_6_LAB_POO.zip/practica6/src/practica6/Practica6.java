/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica6;
import java.util.ArrayList;
/**
 *
 * @author Ruben Ramirez
 */
public class Practica6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Polimorfismo
        ArrayList<IComElectronicos> dispositivos = new ArrayList<>();

        Television tv = new Television("Samsung", 5);
        Radio radio = new Radio("Sony");

        dispositivos.add(tv);
        dispositivos.add(radio);

        // FOR-EACH
        for (IComElectronicos d : dispositivos) {
            d.encender();
            d.subirVolumen(5);
            System.out.println();
        }

        // Métodos específicos
        tv.cambiarCanal(5);
        radio.cambiarFrecuencia(101.5);

        System.out.println();

        // Calculadora
        Calculadora calc = new Calculadora();

        System.out.println("Suma double: " + calc.sumar(5.5, 2.5));
        System.out.println("Suma int (sobrecarga): " + calc.sumar(5, 3));
    }
    
}
