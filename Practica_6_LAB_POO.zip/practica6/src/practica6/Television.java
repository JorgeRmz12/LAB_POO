/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

/**
 *
 * @author Ruben Ramirez
 */
public class Television extends Dispositivo implements IComElectronicos {

    private int canal;

    public Television(String marca, int canal) {
        super(marca);
        this.canal = canal;
    }

    @Override
    public void encender() {
        System.out.println("Television marca " + marca + " encendida");
    }

    @Override
    public void apagar() {
        System.out.println("Television apagada");
    }

    @Override
    public void subirVolumen(int nivel) {
        System.out.println("Subio el volumen en " + nivel);
    }

    public void cambiarCanal(int canal) {
        this.canal = canal;
        System.out.println("Estas viendo el canal: " + canal);
    }
}
