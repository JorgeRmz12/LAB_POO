/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Ruben Ramirez
 */
public class Avion extends Vehiculo implements Volador {

    private int altitudMaxima;

    public Avion(String id, String modelo, int nivelCombustible, int altitudMaxima) {
        super(id, modelo, nivelCombustible);
        this.altitudMaxima = altitudMaxima;
    }

    @Override
    public void validarEstado() throws EstadoInvalidoException {
        if (nivelCombustible < 30) {
            throw new EstadoInvalidoException(
                "Avion " + modelo + " no puede despegar: combustible insuficiente (" + nivelCombustible + "%)"
            );
        }
        System.out.println("Avion " + modelo + " listo para despegar");
    }

    @Override
    public void verificarPlanVuelo() {
        System.out.println("Plan de vuelo verificado para avion " + modelo);
    }
}
