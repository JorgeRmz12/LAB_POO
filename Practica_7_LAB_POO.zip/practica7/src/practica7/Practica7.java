/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica7;

/**
 *
 * @author Ruben Ramirez
 */
public class Practica7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GestionLogistica gestion = new GestionLogistica();

        // Avión con poco combustible (fallará)
        Avion avion = new Avion("A1", "Boeing 737", 15, 10000);

        // Camión correcto
        Camion camion = new Camion("C1", "Volvo FH", 50, 20000);

        gestion.registrarVehiculo(avion);
        gestion.registrarVehiculo(camion);

        gestion.despacharFlota();
    }
    
}
