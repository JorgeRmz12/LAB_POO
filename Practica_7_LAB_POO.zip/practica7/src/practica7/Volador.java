/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package practica7;

/**
 *
 * @author Ruben Ramirez
 */
public interface Volador {

    void verificarPlanVuelo();
}
