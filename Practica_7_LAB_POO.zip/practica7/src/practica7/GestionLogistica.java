/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Ruben Ramirez
 */
public class GestionLogistica {

    private List<Vehiculo> flota;

    public GestionLogistica() {
        flota = new ArrayList<>();
    }

    public void registrarVehiculo(Vehiculo v) {
        flota.add(v);
    }

    public void despacharFlota() {

        for (Vehiculo v : flota) {
            try {
                v.validarEstado();

                // Si es avión, verificar plan de vuelo
                if (v instanceof Avion) {
                    ((Avion) v).verificarPlanVuelo();
                }

            } catch (EstadoInvalidoException e) {
                System.out.println("ERROR: " + e.getMessage());
            }
        }
    }
}
