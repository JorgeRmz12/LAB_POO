/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Ruben Ramirez
 */
public abstract class Vehiculo {

    protected String id;
    protected String modelo;
    protected int nivelCombustible;

    public Vehiculo(String id, String modelo, int nivelCombustible) {
        this.id = id;
        this.modelo = modelo;
        this.nivelCombustible = nivelCombustible;
    }

    // Método abstracto
    public abstract void validarEstado() throws EstadoInvalidoException;

    // Getters
    public String getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public int getNivelCombustible() {
        return nivelCombustible;
    }
}
