/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica7;

/**
 *
 * @author Ruben Ramirez
 */
public class Camion extends Vehiculo {

    private double capacidadCarga;

    public Camion(String id, String modelo, int nivelCombustible, double capacidadCarga) {
        super(id, modelo, nivelCombustible);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void validarEstado() throws EstadoInvalidoException {
        if (nivelCombustible < 10) {
            throw new EstadoInvalidoException(
                "Camion " + modelo + " no puede salir: combustible insuficiente (" + nivelCombustible + "%)"
            );
        }
        System.out.println("Camion " + modelo + " listo para salir");
    }
}
