/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package practica5;

/**
 *
 * @author Ruben Ramirez
 */
public interface SistemaAceleracion {
    void acelerar();
    void frenar();
}
