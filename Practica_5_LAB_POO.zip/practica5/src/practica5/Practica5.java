/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica5;
import java.util.Scanner;

/**
 *
 * @author Ruben Ramirez
 */
public class Practica5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);

        // Automovil
        System.out.print("Ingrese marca del automovil: ");
        String marcaAuto = sc.nextLine();

        System.out.print("Ingrese placa del automovil: ");
        String placaAuto = sc.nextLine();

        System.out.print("Ingrese color del automovil: ");
        String colorAuto = sc.nextLine();

        Automovil auto = new Automovil(marcaAuto, placaAuto, colorAuto);

        auto.encender();
        auto.abrirPuertas();
        auto.mostrarDatos();

        System.out.println();

        // Avion
        System.out.print("Ingrese marca del avion: ");
        String marcaAvion = sc.nextLine();

        System.out.print("Ingrese placa del avion: ");
        String placaAvion = sc.nextLine();

        System.out.print("Ingrese color del avion: ");
        String colorAvion = sc.nextLine();

        Avion avion = new Avion(marcaAvion, placaAvion, colorAvion);

        avion.encender();
        avion.abrirPuertas();
        avion.volar();
        avion.mostrarDatos();
    }
    
}
