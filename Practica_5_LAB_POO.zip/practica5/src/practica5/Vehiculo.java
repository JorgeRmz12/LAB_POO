/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica5;

/**
 *
 * @author Ruben Ramirez
 */

public abstract class Vehiculo {

    protected String marca;
    protected String placa;
    protected String color;

    public Vehiculo(String marca, String placa, String color) {
        this.marca = marca;
        this.placa = placa;
        this.color = color;
    }

    // Métodos abstractos (OBLIGATORIOS de implementar)
    public abstract void encender();
    public abstract void abrirPuertas();

    // Método normal
    public void mostrarDatos() {
        System.out.println("Marca: " + marca);
        System.out.println("Placa: " + placa);
        System.out.println("Color: " + color);
    }
}