/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica3;

/**
 *
 * @author Ruben Ramirez
 */
public class maestro extends persona {

    private String materia;

    public maestro(String nombre, int edad, String direccion, String materia) {
        super(nombre, edad, direccion);
        this.materia = materia;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public void enseñar() {
        System.out.println("El maestro esta dando clases");
    }
}