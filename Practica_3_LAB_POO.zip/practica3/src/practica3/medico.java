/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica3;

/**
 *
 * @author Ruben Ramirez
 */
public class medico extends persona {

    private String especialidad;

    public medico(String nombre, int edad, String direccion, String especialidad) {
        super(nombre, edad, direccion);
        this.especialidad = especialidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public void curar() {
        System.out.println("El medico esta atendiendo pacientes");
    }
}