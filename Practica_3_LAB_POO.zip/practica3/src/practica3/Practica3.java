/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica3;

/**
 *
 * @author Ruben Ramirez
 */
public class Practica3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        persona p = new persona("Pedro Navajas", 25, "Calle falsa 123");
        System.out.println("La persona de nombre: " + p.getNombre()
                + " tiene la edad de: " + p.getEdad()
                + " y vive en: " + p.getDireccion());

        medico m = new medico("Juanito", 25, "Calle falsa 123", "General");
        System.out.println("El doctor de nombre: " + m.getNombre()
                + " tiene: " + m.getEdad()
                + " anios y vive en: " + m.getDireccion());

        plomero pl = new plomero("Juan Alimana", 25, "Calle falsa 123", 5);
        System.out.println("El plomero de nombre: " + pl.getNombre()
                + " tiene: " + pl.getEdad()
                + " anios y vive en: " + pl.getDireccion());

        maestro ma = new maestro("Luis", 30, "Calle falsa 123", "Matematicas");
        System.out.println("El maestro de nombre: " + ma.getNombre()
                + " tiene: " + ma.getEdad()
                + " anios y vive en: " + ma.getDireccion());
    }
}