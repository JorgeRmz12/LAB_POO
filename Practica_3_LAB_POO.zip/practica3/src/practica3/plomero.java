/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica3;

/**
 *
 * @author Ruben Ramirez
 */
public class plomero extends persona {

    private int experiencia;

    public plomero(String nombre, int edad, String direccion, int experiencia) {
        super(nombre, edad, direccion);
        this.experiencia = experiencia;
    }

    public int getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(int experiencia) {
        this.experiencia = experiencia;
    }

    public void reparar() {
        System.out.println("El plomero esta reparando tuberias");
    }
}