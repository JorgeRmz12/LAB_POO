/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.universidad.lab.patrones.factory;

import mx.universidad.lab.patrones.model.*;

public class NotificationFactory {

    public static Notification create(String tipo, String mensaje) {

        tipo = tipo.toUpperCase();

        switch (tipo) {
            case "EMAIL":
                return new EmailNotification(mensaje);
            case "SMS":
                return new SMSNotification(mensaje);
            case "PUSH":
                return new PushNotification(mensaje);
            default:
                throw new IllegalArgumentException("Tipo no valido");
        }
    }
}