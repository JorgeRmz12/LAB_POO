/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.universidad.lab.patrones.singleton;

import java.util.ArrayList;
import java.util.List;

public class NotificationLogger {

    private static NotificationLogger instance;
    private List<String> logs;

    private NotificationLogger() {
        logs = new ArrayList<>();
    }

    public static synchronized NotificationLogger getInstance() {
        if (instance == null) {
            instance = new NotificationLogger();
        }
        return instance;
    }

    public synchronized void log(String mensaje) {
        logs.add(mensaje);
        System.out.println("[LOG] " + mensaje);
    }

    public List<String> getLogs() {
        return logs;
    }
}
