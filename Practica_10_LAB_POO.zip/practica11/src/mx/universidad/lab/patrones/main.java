/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mx.universidad.lab.patrones;

import mx.universidad.lab.patrones.singleton.NotificationLogger;
import mx.universidad.lab.patrones.thread.NotificationWorker;

public class main {

    public static void main(String[] args) throws InterruptedException {

        Thread t1 = new Thread(new NotificationWorker("EMAIL", "Juan", "Hola Juan"));
        Thread t2 = new Thread(new NotificationWorker("SMS", "Maria", "Hola Maria"));
        Thread t3 = new Thread(new NotificationWorker("PUSH", "Carlos", "Hola Carlos"));

        t1.start();
        t2.start();
        t3.start();

        t1.join();
        t2.join();
        t3.join();

        System.out.println("\n--- LOG FINAL ---");

        NotificationLogger.getInstance()
                .getLogs()
                .forEach(System.out::println);
    }
}