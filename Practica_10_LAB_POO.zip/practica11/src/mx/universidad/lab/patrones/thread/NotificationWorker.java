/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.universidad.lab.patrones.thread;

import mx.universidad.lab.patrones.factory.NotificationFactory;
import mx.universidad.lab.patrones.model.Notification;
import mx.universidad.lab.patrones.singleton.NotificationLogger;

public class NotificationWorker implements Runnable {

    private String tipo;
    private String destinatario;
    private String mensaje;

    public NotificationWorker(String tipo, String destinatario, String mensaje) {
        this.tipo = tipo;
        this.destinatario = destinatario;
        this.mensaje = mensaje;
    }

    @Override
    public void run() {

        Notification n = NotificationFactory.create(tipo, mensaje);

        n.send(destinatario);

        NotificationLogger.getInstance()
                .log("Enviado " + n.getType() + " a " + destinatario);
    }
}